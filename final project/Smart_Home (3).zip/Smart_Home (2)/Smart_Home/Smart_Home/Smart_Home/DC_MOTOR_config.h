/*
 * DC_MOTOR_config.h
 *
 * Created: 10/3/2023 5:25:47 PM
 *  Author: youssef
 */ 


#ifndef DC_MOTOR_CONFIG_H_
#define DC_MOTOR_CONFIG_H_


#define DCMOTOR_EN_PORT PORTD
#define DCMOTOR_EN_PIN  PIN4

#define DCMOTOR_A1_PORT PORTC
#define DCMOTOR_A1_PIN  PIN3

#define DCMOTOR_A2_PORT PORTC
#define DCMOTOR_A2_PIN  PIN4



#endif /* DC_MOTOR_CONFIG_H_ */