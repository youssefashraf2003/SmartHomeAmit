/*
 * Keypad_interfcae.h
 *
 * Created: 05/09/2023 16:34:02
 *  Author: AMIT
 */ 


#ifndef KEYPAD_INTERFCAE_H_
#define KEYPAD_INTERFCAE_H_



void KEYPAD_Vid_Init() ; 

u8 KEYPAD_u8_Get_Key() ; 

#endif /* KEYPAD_INTERFCAE_H_ */