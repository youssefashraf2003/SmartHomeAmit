/*
 * BUZZER_config.h
 *
 * Created: 10/3/2023 3:04:31 PM
 *  Author: youssef
 */ 

#include "DIO_interface.h"

#ifndef BUZZER_CONFIG_H_
#define BUZZER_CONFIG_H_

#define BUZZER_PORT PORTA
#define BUZZER_PIN  3


#endif /* BUZZER_CONFIG_H_ */