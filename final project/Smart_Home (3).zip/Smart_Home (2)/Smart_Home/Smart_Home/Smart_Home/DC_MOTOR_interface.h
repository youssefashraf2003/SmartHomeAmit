/*
 * DC_MOTOR_interface.h
 *
 * Created: 10/3/2023 5:25:30 PM
 *  Author: youssef
 */ 


#ifndef DC_MOTOR_INTERFACE_H_
#define DC_MOTOR_INTERFACE_H_

void DCMOTOR_Vid_Init();
void DCMOTOR_Vid_CW();
void DCMOTOR_Vid_ACW();
void DCMOTOR_Vid_Stop();

#endif /* DC_MOTOR_INTERFACE_H_ */