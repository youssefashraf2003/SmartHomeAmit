/*
 * BUZZER_interface.h
 *
 * Created: 10/3/2023 3:04:56 PM
 *  Author: youssef
 */ 


#ifndef BUZZER_INTERFACE_H_
#define BUZZER_INTERFACE_H_

void BUZZER_Vid_Init();
void BUZZER_Vid_On();
void BUZZER_Vid_Off();

#endif /* BUZZER_INTERFACE_H_ */