#ifndef _GIE_PRIVATE_h
#define _GIE_PRIVATE_h

/* SREG_REG RESPONSIBLE FOR ENABLING THE THE GLOBAL INTERRUPT */
#define SREG_REG  *((volatile u8*)0x5F)

#endif